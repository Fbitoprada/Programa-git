package gest_clinic;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GestClinicApplication {

	public static void main(String[] args) {
		SpringApplication.run(GestClinicApplication.class, args);
	}

}
	