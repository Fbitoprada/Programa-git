package gest_clinic.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class LoginController {

    @GetMapping("/login")
    public String login() {
        return "login"; 
    }

    @GetMapping("/redirect")
    public String redirectAfterLogin(org.springframework.security.core.Authentication auth) {
        if (auth.getAuthorities().stream()
                .anyMatch(r -> r.getAuthority().equals("ROLE_MEDICO"))) {
            return "redirect:/medico/menu_medico";
        } else if (auth.getAuthorities().stream()
                .anyMatch(r -> r.getAuthority().equals("ROLE_ADMINISTRATIVO"))) {
            return "redirect:/admin/menu_admin";
        }
        return "redirect:/login?error";
    }
}