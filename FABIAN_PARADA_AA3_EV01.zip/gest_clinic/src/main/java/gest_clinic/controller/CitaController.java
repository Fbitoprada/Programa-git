package gest_clinic.controller;

import gest_clinic.model.cita;
import gest_clinic.model.paciente;
import gest_clinic.model.Medico;
import gest_clinic.repository.CitaRepository;
import gest_clinic.repository.Paciente_Repository;
import gest_clinic.repository.Medico_Repository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping("/citas")
public class CitaController {

    @Autowired
    private CitaRepository citaRepository;

    @Autowired
    private Paciente_Repository pacienteRepository;

    @Autowired
    private Medico_Repository medicoRepository;

    // 📌 Listar citas
    @GetMapping
    public String listar(Model model) {
        model.addAttribute("citas", citaRepository.findAll());
        return "citas/list"; // vista: citas/list.html
    }

    // Mostrar formulario para nueva cita
    @GetMapping("/new")
    public String mostrarFormulario(Model model) {
        model.addAttribute("cita", new cita());
        model.addAttribute("pacientes", pacienteRepository.findAll());
        model.addAttribute("medicos", medicoRepository.findAll());
        return "citas/form"; // vista: citas/form.html
    }

    // Guardar cita
    @PostMapping("/save")
    public String guardar(
            @RequestParam("pacienteId") Long pacienteId,
            @RequestParam("medicoId") Long medicoId,
            @ModelAttribute cita cita) {

        // Buscar paciente y médico por ID
        paciente paciente = pacienteRepository.findById(pacienteId)
                .orElseThrow(() -> new IllegalArgumentException("Paciente no encontrado con id: " + pacienteId));
        Medico medico = medicoRepository.findById(medicoId)
                .orElseThrow(() -> new IllegalArgumentException("Médico no encontrado con id: " + medicoId));

        // Asignar al objeto cita
        cita.setPaciente(paciente);
        cita.setMedico(medico);

        // Guardar en la BD
        citaRepository.save(cita);

        return "redirect:/citas";
    }
}