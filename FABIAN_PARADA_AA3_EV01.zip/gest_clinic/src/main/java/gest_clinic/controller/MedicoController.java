package gest_clinic.controller;

import gest_clinic.model.Medico;
import gest_clinic.repository.Medico_Repository;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping("/medicos")
public class MedicoController {

    private final Medico_Repository medicoRepository;

    public MedicoController(Medico_Repository medicoRepository) {
        this.medicoRepository = medicoRepository;
    }

    // Listar médicos
    @GetMapping
    public String listar(Model model) {
        model.addAttribute("medicos", medicoRepository.findAll());
        return "medicos/list"; // templates/medicos/list.html
    }

    // Mostrar formulario de nuevo médico
    @GetMapping("/new")
    public String mostrarFormularioNuevo(Model model) {
        model.addAttribute("medico", new Medico());
        return "medicos/form"; // templates/medicos/form.html
    }

    // Guardar médico 
    @PostMapping("/save")
    public String guardar(@ModelAttribute Medico medico) {
        medicoRepository.save(medico);
        return "redirect:/medicos";
    }

    // Editar médico
    @GetMapping("/edit/{id}")
    public String editar(@PathVariable Long id, Model model) {
        Medico medico = medicoRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Médico no encontrado: " + id));
        model.addAttribute("medico", medico);
        return "medicos/form";
    }

    // Eliminar médico
    @GetMapping("/delete/{id}")
    public String eliminar(@PathVariable Long id) {
        medicoRepository.deleteById(id);
        return "redirect:/medicos";
    }

    
    @GetMapping("/desactivar/{id}")
    public String desactivar(@PathVariable Long id) {
        Medico medico = medicoRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Médico no encontrado: " + id));
        medico.setActivo(false);
        medicoRepository.save(medico);
        return "redirect:/medicos";
    }

    
    @GetMapping("/activar/{id}")
    public String activar(@PathVariable Long id) {
        Medico medico = medicoRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Médico no encontrado: " + id));
        medico.setActivo(true);
        medicoRepository.save(medico);
        return "redirect:/medicos";
    }
}