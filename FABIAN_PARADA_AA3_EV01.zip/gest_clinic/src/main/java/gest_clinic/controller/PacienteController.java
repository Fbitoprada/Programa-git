package gest_clinic.controller;

import gest_clinic.model.paciente;
import gest_clinic.repository.Paciente_Repository;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping("/pacientes")
	

public class PacienteController {

	 private final Paciente_Repository pacienteRepository;

	    public PacienteController(Paciente_Repository pacienteRepository) {
	        this.pacienteRepository = pacienteRepository;
	    }

	    // Listar pacientes
	    @GetMapping
	    public String listar(Model model) {
	        model.addAttribute("pacientes", pacienteRepository.findAll());
	        return "pacientes/list"; 
	    }

	    // Mostrar formulario de nuevo paciente
	    @GetMapping("/new")
	    public String mostrarFormularioNuevo(Model model) {
	        model.addAttribute("paciente", new paciente());
	        return "pacientes/editar"; 
	    }

	    // Guardar paciente (nuevo o editado)
	    @PostMapping("/save")
	    public String guardar(@ModelAttribute paciente paciente) {
	        pacienteRepository.save(paciente);
	        return "redirect:/pacientes";
	    }

	    // Editar paciente
	    @GetMapping("/edit/{id}")
	    public String editar(@PathVariable Long id, Model model) {
	        paciente paciente = pacienteRepository.findById(id)
	                .orElseThrow(() -> new IllegalArgumentException("Paciente no encontrado: " + id));
	        model.addAttribute("paciente", paciente);
	        return "pacientes/editar"; 
	    }

	    // Eliminar paciente
	    @GetMapping("/delete/{id}")
	    public String eliminar(@PathVariable Long id) {
	        pacienteRepository.deleteById(id);
	        return "redirect:/pacientes";
	    }
	}