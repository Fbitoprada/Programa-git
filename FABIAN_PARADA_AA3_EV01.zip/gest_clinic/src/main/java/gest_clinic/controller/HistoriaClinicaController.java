package gest_clinic.controller;
import gest_clinic.model.HistoriaClinica;
import gest_clinic.repository.HistoriaClinicaRepository;
import gest_clinic.repository.Paciente_Repository;
import gest_clinic.repository.Medico_Repository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import gest_clinic.model.paciente;
import gest_clinic.model.Medico;
import java.time.LocalDate;


@Controller
@RequestMapping("/historias")
public class HistoriaClinicaController {

    @Autowired
    private HistoriaClinicaRepository historiaClinicaRepository;

    @Autowired
    private Paciente_Repository pacienteRepository;

    @Autowired
    private Medico_Repository medicoRepository;

    // 📌 Listar todas
    @GetMapping
    public String listar(Model model) {
        model.addAttribute("historias", historiaClinicaRepository.findAll());
        return "historias/list";
    }

    // 📌 Mostrar formulario nueva historia
    @GetMapping("/nueva")
    public String mostrarFormulario(Model model) {
        model.addAttribute("historiaClinica", new HistoriaClinica());
        model.addAttribute("pacientes", pacienteRepository.findAll());
        model.addAttribute("medicos", medicoRepository.findAll());
        return "historias/form";
    }

    // 📌 Guardar historia
    @PostMapping("/guardar")
    public String guardarHistoria(@ModelAttribute HistoriaClinica historia,
                                  @RequestParam(value = "medico_id", required = false) Long medicoId) {
        try {
            // Si no se selecciona médico, se asigna por defecto el de ID 1
            Medico medico = medicoRepository.findById(medicoId != null ? medicoId : 1L)
                    .orElseThrow(() -> new RuntimeException("Médico no encontrado"));

            historia.setMedico(medico);

            // Si no se envía fecha, se asigna la actual
            if (historia.getFechaApertura() == null) {
                historia.setFechaApertura(LocalDate.now());
            }

            historiaClinicaRepository.save(historia);
            System.out.println("Historia clínica guardada correctamente.");

            return "redirect:/historias";
        } catch (Exception e) {
            e.printStackTrace();
            System.out.println("Error al guardar la historia clínica: " + e.getMessage());
            return "error"; 
        }
    }
}