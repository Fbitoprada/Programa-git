package gest_clinic.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import gest_clinic.model.paciente;

public interface Paciente_Repository extends JpaRepository<paciente, Long> {
}