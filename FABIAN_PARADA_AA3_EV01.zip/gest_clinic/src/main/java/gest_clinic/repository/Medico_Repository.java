package gest_clinic.repository;

import gest_clinic.model.Medico;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface Medico_Repository extends JpaRepository<Medico, Long> {
    List<Medico> findByActivoTrue(); // devuelve solo los activos
}