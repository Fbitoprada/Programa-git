package gest_clinic.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import gest_clinic.model.cita;

public interface CitaRepository extends JpaRepository<cita, Long> {
}