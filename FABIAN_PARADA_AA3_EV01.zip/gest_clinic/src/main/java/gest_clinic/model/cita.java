package gest_clinic.model;

import jakarta.persistence.*;
import java.time.LocalDate;

@Entity
@Table(name = "cita_medica")
public class cita {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "ID_Cita")
    private Long id;

    @Column(name = "Fecha_Cita")
    private LocalDate fechaCita;

    @Column(name = "Motivo")
    private String motivo;

    // Relación con Paciente
    @ManyToOne
    @JoinColumn(name = "Paciente_ID_Paciente")
    private paciente paciente;

    // Relación con Médico
    @ManyToOne
    @JoinColumn(name = "Medico_ID_Medico")
    private Medico medico;

    // Getters y Setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public LocalDate getFechaCita() {
        return fechaCita;
    }

    public void setFechaCita(LocalDate fechaCita) {
        this.fechaCita = fechaCita;
    }

    public String getMotivo() {
        return motivo;
    }

    public void setMotivo(String motivo) {
        this.motivo = motivo;
    }

    public paciente getPaciente() {
        return paciente;
    }

    public void setPaciente(paciente paciente) {
        this.paciente = paciente;
    }

    public Medico getMedico() {
        return medico;
    }

    public void setMedico(Medico medico) {
        this.medico = medico;
    }
}