package gest_clinic.model;

public enum Rol {
    MEDICO,
    ADMINISTRATIVO
}