package gest_clinic.service;

import gest_clinic.model.Medico;
import gest_clinic.repository.Medico_Repository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class MedicoService {

    private final Medico_Repository medicoRepository;

    public MedicoService(Medico_Repository medicoRepository) {
        this.medicoRepository = medicoRepository;
    }

    public List<Medico> listarActivos() {
        return medicoRepository.findByActivoTrue();
    }

    public Medico guardar(Medico medico) {
        medico.setActivo(true);
        return medicoRepository.save(medico);
    }

    public Medico buscarPorId(Long id) {
        return medicoRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Médico no encontrado"));
    }

    public void eliminarLogico(Long id) {
        Medico medico = buscarPorId(id);
        medico.setActivo(false);
        medicoRepository.save(medico); 
    }
}
